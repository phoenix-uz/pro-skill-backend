export const ResponseStatus = {
  Ok: 'OK',
  Failed: 'FAILED',
  Cancelled: 'CANCELLED',
  Created: 'CREATED',
  Confirmed: 'CONFIRMED',
  Reversed: 'REVERSED',
};
