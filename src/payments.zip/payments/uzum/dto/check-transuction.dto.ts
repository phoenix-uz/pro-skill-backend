export class CheckTransactionDto {
    serviceId: number;
    timestamp: number;
    params: {
      [key: string]: any;
    };
  }