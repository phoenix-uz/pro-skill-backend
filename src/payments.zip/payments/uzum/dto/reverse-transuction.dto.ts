export class ReverseTransactionDto {
    serviceId: number;
    transId: string;
    timestamp: number;
  }