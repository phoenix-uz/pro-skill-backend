export class CheckTransactionStatusDto {
    serviceId: number;
    transId: string;
    timestamp: number;
}