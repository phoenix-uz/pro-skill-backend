export class RequestDto {
    serviceId: number;
    timestamp: number;
    status: string;
    data?: object;
  }