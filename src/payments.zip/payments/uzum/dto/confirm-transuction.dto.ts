export class ConfirmTransactionDto {
    serviceId: number;
    timestamp: number;
    transId: string;
  }