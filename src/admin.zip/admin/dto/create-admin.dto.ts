export class CreateAdminDto {}
